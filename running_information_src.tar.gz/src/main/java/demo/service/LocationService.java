package demo.service;

import demo.domain.Location;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

import java.util.List;

public interface LocationService {
    List<Location> saveRunningInformation(List<Location> runningInformation);
    Page<Location> findAll(Pageable pageable);
    Page<Location> deleteByRunningId(String runningId, Pageable pageable);
}
