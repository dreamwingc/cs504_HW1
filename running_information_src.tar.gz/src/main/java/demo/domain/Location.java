package demo.domain;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonInclude;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

import javax.persistence.*;
import java.util.Date;
import java.util.Random;

@Data
@Entity
@Table(name = "RUNNING_ANALYSIS")
@JsonInclude(JsonInclude.Include.NON_NULL)
//@JsonIgnoreProperties({"latitude", "longitude", "runningDistance", "timestamp", "heartRate"})
public class Location {

    @Id
    @GeneratedValue
    private Long userId;

    @Embedded
    @AttributeOverrides({
            @AttributeOverride(name = "username", column = @Column(name = "userName")),
            @AttributeOverride(name = "address", column = @Column(name = "userAddress"))
    })
    private final UserInfo userInfo;

    private String runningId;

    private double totalRunningTime;
    private int heartRate;

    //@Transient
    //private double latitude;

    //@Transient
    //private double longitude;

    //@Transient
    //private double runningDistance;

    //@Transient
    //private Date timestamp = new Date();

    public Location(){
        this.userInfo = null;
        //this.heartRate = new Random().nextInt(141) + 60;
    }

    //@JsonCreator
    //public Location(@JsonProperty("username") String username, @JsonProperty("address") String address){
    //    this.userInfo = new UserInfo(username, address);
    //}

    @JsonCreator
    public Location(@JsonProperty("userInfo") UserInfo userInfo){
        this.userInfo = userInfo;
    }

    public String getUserName(){ return this.userInfo == null ? null : this.userInfo.getUsername(); }

    public void setHeartRate(int heartRate){
        int min = 60;
        int max = 200;

        this.heartRate = new Random().nextInt((max - min + 1)) + min;
    }
}
