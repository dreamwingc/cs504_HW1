package demo.rest;

import demo.domain.Location;
import demo.service.LocationService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
public class RunningInformationRestController {

    private LocationService locationService;

    @Autowired
    public RunningInformationRestController(LocationService locationService){
        this.locationService = locationService;
    }

    @RequestMapping(value = "/running", method = RequestMethod.POST)
    @ResponseStatus(HttpStatus.CREATED)
    public List<Location> upload(@RequestBody List<Location> runningInformation){
        return this.locationService.saveRunningInformation(runningInformation);
    }

    @RequestMapping(value = "/running", method = RequestMethod.GET)
    public Page<Location> findAll(@RequestParam(name = "page") int page, @RequestParam(name = "size") int size){
        return this.locationService.findAll(new PageRequest(page, size));
    }

    @RequestMapping(value = "/running/{runningId}", method = RequestMethod.GET)
    public Page<Location> deleteByRunningId(@PathVariable String runningId, @RequestParam(name = "page") int page, @RequestParam(name = "size") int size){
        return this.locationService.deleteByRunningId(runningId,new PageRequest(page, size));
    }
}
